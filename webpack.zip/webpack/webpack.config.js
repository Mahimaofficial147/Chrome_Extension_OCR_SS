const path = require('path');

module.exports = {
  entry: './popup.js',
  output: {
    filename: 'main.js',
    path: path.resolve(__dirname, 'webpack/dist'),
  },
};
